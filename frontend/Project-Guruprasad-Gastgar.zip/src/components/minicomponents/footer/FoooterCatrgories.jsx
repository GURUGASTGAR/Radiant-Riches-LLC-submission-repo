
const FoooterCatrgories = () => {
  return (
    <div className="flex flex-col justify-start gap-y-5 text-gray-400">
        <div className="font-semibold text-white">CATEGORIES</div>
        <div>Web Builder</div>
        <div>Hosting</div>
        <div>Data Center</div>
        <div>Robotics-Automation</div>
    </div>
  )
}

export default FoooterCatrgories