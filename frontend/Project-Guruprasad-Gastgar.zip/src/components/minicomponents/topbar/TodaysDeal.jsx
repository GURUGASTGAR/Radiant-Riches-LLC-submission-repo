
const TodaysDeal = () => {
  return (
    <div className="text-white">{"Today's Deal"}</div>
  )
}

export default TodaysDeal