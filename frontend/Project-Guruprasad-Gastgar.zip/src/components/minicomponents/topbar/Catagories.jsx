

const Catagories = () => {
  return (
    <div className='text-white'>Catagories</div>
  )
}

export default Catagories